import math
import os
from dataclasses import dataclass
from typing import List, Tuple


# ============================================================
# Simplified SHA-256-like hash (educational, not production)
# ============================================================

_IV = [
    0x6A09E667,
    0xBB67AE85,
    0x3C6EF372,
    0xA54FF53A,
    0x510E527F,
    0x9B05688C,
    0x1F83D9AB,
    0x5BE0CD19,
]

_K = [
    0x428A2F98,
    0x71374491,
    0xB5C0FBCF,
    0xE9B5DBA5,
    0x3956C25B,
    0x59F111F1,
    0x923F82A4,
    0xAB1C5ED5,
]


def _rotr(x: int, n: int) -> int:
    return ((x >> n) | (x << (32 - n))) & 0xFFFFFFFF


def simple_sha256(data: bytes) -> bytes:
    """Very small, simplified SHA-256-like hash (NOT secure, exam use only)."""
    # Padding (bit length in last 64 bits)
    bit_len = len(data) * 8
    data += b"\x80"
    while (len(data) * 8) % 512 != 448:
        data += b"\x00"
    data += bit_len.to_bytes(8, "big")

    h = _IV[:]
    for chunk_start in range(0, len(data), 64):
        chunk = data[chunk_start : chunk_start + 64]
        w = [int.from_bytes(chunk[i : i + 4], "big") for i in range(0, 64, 4)]
        for i in range(16, 64):
            s0 = _rotr(w[i - 15], 7) ^ _rotr(w[i - 15], 18) ^ (w[i - 15] >> 3)
            s1 = _rotr(w[i - 2], 17) ^ _rotr(w[i - 2], 19) ^ (w[i - 2] >> 10)
            w.append((w[i - 16] + s0 + w[i - 7] + s1) & 0xFFFFFFFF)

        a, b, c, d, e, f, g, h_val = h
        for i in range(64):
            s1 = _rotr(e, 6) ^ _rotr(e, 11) ^ _rotr(e, 25)
            ch = (e & f) ^ (~e & g)
            temp1 = (h_val + s1 + ch + _K[i % len(_K)] + w[i]) & 0xFFFFFFFF
            s0 = _rotr(a, 2) ^ _rotr(a, 13) ^ _rotr(a, 22)
            maj = (a & b) ^ (a & c) ^ (b & c)
            temp2 = (s0 + maj) & 0xFFFFFFFF

            h_val = g
            g = f
            f = e
            e = (d + temp1) & 0xFFFFFFFF
            d = c
            c = b
            b = a
            a = (temp1 + temp2) & 0xFFFFFFFF

        h = [
            (x + y) & 0xFFFFFFFF for x, y in zip(h, [a, b, c, d, e, f, g, h_val])
        ]

    return b"".join(x.to_bytes(4, "big") for x in h)


# ============================================================
# Merkle tree with proof generation / verification
# ============================================================


def merkle_tree(leaves: List[bytes]) -> Tuple[bytes, List[List[bytes]]]:
    """Build a Merkle tree from leaves; return (root, levels)."""
    if not leaves:
        empty_hash = simple_sha256(b"")
        return empty_hash, [[empty_hash]]
    level = [simple_sha256(leaf) for leaf in leaves]
    levels = [level]
    while len(level) > 1:
        next_level = []
        for i in range(0, len(level), 2):
            left = level[i]
            right = level[i + 1] if i + 1 < len(level) else level[i]
            next_level.append(simple_sha256(left + right))
        level = next_level
        levels.append(level)
    return level[0], levels


def merkle_proof(index: int, levels: List[List[bytes]]) -> List[Tuple[bytes, str]]:
    """
    Build a proof for leaf at index.
    Returns list of (sibling_hash, position) where position is 'L' or 'R'.
    """
    proof: List[Tuple[bytes, str]] = []
    pos = index
    for level in levels[:-1]:
        if pos % 2 == 0:  # left node
            sibling_index = pos + 1 if pos + 1 < len(level) else pos
            position = "R"
        else:
            sibling_index = pos - 1
            position = "L"
        proof.append((level[sibling_index], position))
        pos //= 2
    return proof


def verify_merkle_proof(
    leaf: bytes, index: int, root: bytes, proof: List[Tuple[bytes, str]]
) -> bool:
    h = simple_sha256(leaf)
    pos = index
    for sibling_hash, position in proof:
        if position == "R":
            h = simple_sha256(h + sibling_hash)
        else:
            h = simple_sha256(sibling_hash + h)
        pos //= 2
    return h == root


# ============================================================
# XOR Stream cipher with LFSR
# ============================================================

@dataclass
class LFSR:
    state: int
    taps: List[int]
    size: int

    def step(self) -> int:
        """Return next bit and update state."""
        feedback = 0
        for t in self.taps:
            feedback ^= (self.state >> t) & 1
        out = self.state & 1
        self.state = ((self.state >> 1) | (feedback << (self.size - 1))) & (
            (1 << self.size) - 1
        )
        return out

    def keystream(self, n_bytes: int) -> bytes:
        out = bytearray()
        for _ in range(n_bytes):
            val = 0
            for bit in range(8):
                val |= self.step() << bit
            out.append(val)
        return bytes(out)


def xor_stream_cipher(key: bytes, data: bytes) -> bytes:
    """Encrypt/decrypt with XOR stream cipher based on an LFSR."""
    # Seed LFSR with key hash
    seed = int.from_bytes(simple_sha256(key)[:4], "big") or 1
    lfsr = LFSR(state=seed, taps=[0, 2, 3, 5], size=16)
    ks = lfsr.keystream(len(data))
    return bytes(a ^ b for a, b in zip(data, ks))


# ============================================================
# RSA key generation and modular exponentiation
# ============================================================


def _is_probable_prime(n: int, k: int = 10) -> bool:
    if n < 2:
        return False
    small_primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
    for p in small_primes:
        if n == p:
            return True
        if n % p == 0:
            return False
    # Miller-Rabin
    r, d = 0, n - 1
    while d % 2 == 0:
        r += 1
        d //= 2
    for _ in range(k):
        a = 2 + (os.urandom(2)[0] % (n - 3))
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = (x * x) % n
            if x == n - 1:
                break
        else:
            return False
    return True


def _generate_prime(bits: int) -> int:
    while True:
        candidate = int.from_bytes(os.urandom(bits // 8), "big") | 1 | (1 << (bits - 1))
        if _is_probable_prime(candidate):
            return candidate


def egcd(a: int, b: int) -> Tuple[int, int, int]:
    if b == 0:
        return a, 1, 0
    g, x1, y1 = egcd(b, a % b)
    return g, y1, x1 - (a // b) * y1


def modinv(a: int, m: int) -> int:
    g, x, _ = egcd(a, m)
    if g != 1:
        raise ValueError("No modular inverse")
    return x % m


def modexp(base: int, exp: int, mod: int) -> int:
    """Square-and-multiply modular exponentiation."""
    result = 1
    base = base % mod
    while exp > 0:
        if exp & 1:
            result = (result * base) % mod
        base = (base * base) % mod
        exp >>= 1
    return result


def generate_rsa_keypair(bits: int = 1024) -> Tuple[Tuple[int, int], Tuple[int, int]]:
    """Return (public, private) keys as ((n, e), (n, d))."""
    p = _generate_prime(bits // 2)
    q = _generate_prime(bits // 2)
    n = p * q
    phi = (p - 1) * (q - 1)
    e = 65537
    d = modinv(e, phi)
    return (n, e), (n, d)


def rsa_encrypt(pub: Tuple[int, int], m: int) -> int:
    n, e = pub
    return modexp(m, e, n)


def rsa_decrypt(priv: Tuple[int, int], c: int) -> int:
    n, d = priv
    return modexp(c, d, n)


