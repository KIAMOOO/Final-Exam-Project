from getpass import getpass

from cryptography.hazmat.primitives import serialization

from cryptovault import CryptoVault
from messaging import MessagingIdentity, MessagingModule


def main() -> None:
    vault = CryptoVault()
    print("=== CryptoVault Demo ===")
    username = input("Choose username: ")
    password = getpass("Choose strong password: ")

    reg_info = vault.register(username, password)
    print("\nUser registered.")
    print("TOTP URI (add to authenticator app):")
    print(reg_info["totp_uri"])
    print("Sample backup codes (format Cx:CODE_Cx):")
    print(reg_info["backup_codes"])

    input("\nPress Enter when you are ready to login with your TOTP code...")
    login_pw = getpass("Password: ")
    totp_code = input("Enter current TOTP code (or backup code like C1:CODE_C1): ")
    token = vault.login(username, login_pw, totp_code)
    print(f"\nLogin successful. Session token (shortened): {token[:40]}...")

    # File encryption demo
    print("\n=== File Encryption Demo ===")
    sample_file = "sample.txt"
    with open(sample_file, "w", encoding="utf-8") as f:
        f.write("This is a sample file for CryptoVault.\n")

    enc_res = vault.encrypt_file(username, sample_file, password)
    enc_path = enc_res["encrypted_path"].decode("utf-8")
    print(f"Encrypted file written to: {enc_path}")
    dec_out = "sample_decrypted.txt"
    vault.decrypt_file(username, enc_path, password, dec_out)
    print(f"Decrypted file written to: {dec_out}")

    # Secure messaging demo (Alice -> Bob)
    print("\n=== Secure Messaging Demo ===")
    alice_identity = MessagingIdentity.generate()
    bob_identity = MessagingIdentity.generate()
    alice = MessagingModule(alice_identity)
    bob = MessagingModule(bob_identity)

    bob_ecdh_pub_der = bob_identity.ecdh_private_key.public_key().public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    msg = "Hello from Alice to Bob (secure)!"
    payload = alice.send_message(bob_ecdh_pub_der, msg)

    alice_sign_pub_raw = (
        alice_identity.signing_private_key.public_key().public_bytes(
            serialization.Encoding.Raw, serialization.PublicFormat.Raw
        )
    )
    received = bob.receive_message(alice_sign_pub_raw, payload)
    print(f"Bob received message: {received}")

    print("\n=== Blockchain Ledger ===")
    print(f"Current chain length: {len(vault.ledger.chain)} blocks")
    print("Demo complete.")


if __name__ == "__main__":
    main()



