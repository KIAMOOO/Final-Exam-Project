import hashlib
import hmac
import os
from typing import Dict, BinaryIO

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC


def _derive_master_key(password: str, salt: bytes, iterations: int = 100_000) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=iterations,
    )
    return kdf.derive(password.encode("utf-8"))


class FileEncryptionModule:
    """
    File encryption using:
    - PBKDF2 master key from password
    - Random FEK encrypted under master key
    - AES-256-GCM streaming
    - SHA-256 and HMAC-SHA256 integrity
    """

    def encrypt_file(self, filepath: str, password: str) -> Dict[str, bytes]:
        salt = os.urandom(32)
        master_key = _derive_master_key(password, salt)
        fek = os.urandom(32)

        # Wrap FEK under master key using AES-GCM
        wrap_nonce = os.urandom(12)
        wrap_encryptor = Cipher(
            algorithms.AES(master_key), modes.GCM(wrap_nonce)
        ).encryptor()
        wrapped_fek = wrap_encryptor.update(fek) + wrap_encryptor.finalize()
        wrap_tag = wrap_encryptor.tag

        file_nonce = os.urandom(12)
        encryptor = Cipher(
            algorithms.AES(fek), modes.GCM(file_nonce)
        ).encryptor()

        sha256 = hashlib.sha256()
        hmac_key = master_key  # for demo, reuse; better: derive separate key
        h = hmac.new(hmac_key, digestmod=hashlib.sha256)

        out_path = filepath + ".enc"
        with open(filepath, "rb") as f_in, open(out_path, "wb") as f_out:
            # header: salt | wrap_nonce | wrap_tag | wrapped_fek | file_nonce
            f_out.write(
                salt
                + wrap_nonce
                + wrap_tag
                + len(wrapped_fek).to_bytes(2, "big")
                + wrapped_fek
                + file_nonce
            )

            for chunk in iter(lambda: f_in.read(4096), b""):
                sha256.update(chunk)
                h.update(chunk)
                ct = encryptor.update(chunk)
                f_out.write(ct)
            encryptor.finalize()
            f_out.write(encryptor.tag)

        return {
            "encrypted_path": out_path.encode("utf-8"),
            "file_sha256": sha256.digest(),
            "file_hmac": h.digest(),
        }

    def decrypt_file(self, enc_path: str, password: str, out_path: str) -> Dict[str, bytes]:
        with open(enc_path, "rb") as f_in:
            salt = f_in.read(32)
            wrap_nonce = f_in.read(12)
            wrap_tag = f_in.read(16)
            fek_len = int.from_bytes(f_in.read(2), "big")
            wrapped_fek = f_in.read(fek_len)
            file_nonce = f_in.read(12)

            master_key = _derive_master_key(password, salt)
            wrap_decryptor = Cipher(
                algorithms.AES(master_key), modes.GCM(wrap_nonce, wrap_tag)
            ).decryptor()
            fek = wrap_decryptor.update(wrapped_fek) + wrap_decryptor.finalize()

            # ciphertext + tag
            file_data = f_in.read()
            if len(file_data) < 16:
                raise ValueError("Encrypted file too short")
            tag = file_data[-16:]
            ciphertext = file_data[:-16]

        decryptor = Cipher(
            algorithms.AES(fek), modes.GCM(file_nonce, tag)
        ).decryptor()

        sha256 = hashlib.sha256()
        hmac_key = master_key
        h = hmac.new(hmac_key, digestmod=hashlib.sha256)

        with open(out_path, "wb") as f_out:
            # stream decrypt in chunks from ciphertext buffer
            buf_io: BinaryIO
            pos = 0
            chunk_size = 4096
            while pos < len(ciphertext):
                chunk = ciphertext[pos : pos + chunk_size]
                pos += chunk_size
                pt = decryptor.update(chunk)
                sha256.update(pt)
                h.update(pt)
                f_out.write(pt)
            decryptor.finalize()

        return {
            "decrypted_path": out_path.encode("utf-8"),
            "file_sha256": sha256.digest(),
            "file_hmac": h.digest(),
        }


