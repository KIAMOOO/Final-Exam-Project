from pathlib import Path

from flask import (
    Flask,
    flash,
    redirect,
    render_template,
    request,
    send_file,
    session,
    url_for,
)

from cryptovault import CryptoVault


BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

app = Flask(__name__)
app.secret_key = "dev-secret-key-change-me"  # Flask session signing (separate from CryptoVault)

vault = CryptoVault()


def current_user() -> str | None:
    return session.get("username")


@app.route("/")
def index():
    return render_template("index.html", user=current_user())


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        try:
            info = vault.register(username, password)
        except Exception as e:  # noqa: BLE001
            flash(str(e), "danger")
            return render_template("register.html")
        # Show TOTP URI and backup codes so user can save them
        return render_template(
            "register_success.html",
            username=username,
            totp_uri=info["totp_uri"],
            backup_codes=info["backup_codes"],
        )
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        totp = request.form.get("totp", "")
        try:
            token = vault.login(username, password, totp)
            session["username"] = username
            session["token"] = token
            flash("Logged in successfully.", "success")
            return redirect(url_for("dashboard"))
        except Exception as e:  # noqa: BLE001
            flash(str(e), "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out.", "info")
    return redirect(url_for("index"))


@app.route("/dashboard")
def dashboard():
    user = current_user()
    if not user:
        return redirect(url_for("login"))
    return render_template("dashboard.html", user=user, chain=vault.ledger.chain)


@app.route("/encrypt", methods=["POST"])
def encrypt_file():
    user = current_user()
    if not user:
        return redirect(url_for("login"))
    file = request.files.get("file")
    password = request.form.get("password", "")
    if not file or not password:
        flash("File and password are required.", "danger")
        return redirect(url_for("dashboard"))
    filename = file.filename or "upload.bin"
    src_path = UPLOAD_DIR / filename
    file.save(src_path)
    try:
        result = vault.encrypt_file(user, str(src_path), password)
    except Exception as e:  # noqa: BLE001
        flash(str(e), "danger")
        return redirect(url_for("dashboard"))
    enc_path = Path(result["encrypted_path"].decode("utf-8"))
    flash(f"File encrypted: {enc_path.name}", "success")
    session["last_enc_path"] = str(enc_path)
    return redirect(url_for("dashboard"))


@app.route("/decrypt", methods=["POST"])
def decrypt_file():
    user = current_user()
    if not user:
        return redirect(url_for("login"))
    password = request.form.get("password", "")
    enc_path = session.get("last_enc_path")
    if not enc_path or not password:
        flash("No encrypted file in session or missing password.", "danger")
        return redirect(url_for("dashboard"))
    enc_path_p = Path(enc_path)
    out_path = enc_path_p.with_suffix(".dec")
    try:
        vault.decrypt_file(user, str(enc_path_p), password, str(out_path))
    except Exception as e:  # noqa: BLE001
        flash(str(e), "danger")
        return redirect(url_for("dashboard"))
    flash(f"File decrypted: {out_path.name}", "success")
    return send_file(out_path, as_attachment=True)


@app.route("/chain")
def chain():
    user = current_user()
    if not user:
        return redirect(url_for("login"))
    return render_template("chain.html", chain=vault.ledger.chain)


if __name__ == "__main__":
    app.run(debug=True)


