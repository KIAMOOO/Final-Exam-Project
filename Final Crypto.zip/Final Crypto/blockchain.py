import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from core_crypto import merkle_tree, simple_sha256


def _sha256(data: bytes) -> bytes:
    # Use our educational hash to satisfy "from scratch" requirement for this module
    return simple_sha256(data)


def _hash_dict(d: Dict[str, Any]) -> bytes:
    items = sorted(d.items())
    serialized = ";".join(f"{k}={v}" for k, v in items).encode("utf-8")
    return _sha256(serialized)


@dataclass
class Block:
    index: int
    timestamp: int
    prev_hash: bytes
    merkle_root: bytes
    nonce: int
    hash: bytes
    transactions: List[Dict[str, Any]] = field(default_factory=list)


class BlockchainModule:
    """
    Simple blockchain with:
    - Block structure (prev hash, merkle root, timestamp, nonce, hash)
    - Merkle tree for transactions
    - Proof-of-work
    """

    def __init__(self, difficulty: int = 4):
        self.chain: List[Block] = []
        self.pending_transactions: List[Dict[str, Any]] = []
        self.difficulty = difficulty
        self._create_genesis_block()

    def _create_genesis_block(self) -> None:
        txs: List[Dict[str, Any]] = [{"type": "GENESIS"}]
        root, _ = merkle_tree([_hash_dict(tx) for tx in txs])
        block = self._mine_block(0, b"\x00" * 32, root, txs)
        self.chain.append(block)

    # -------------- Merkle tree helpers --------------
    def build_merkle_root(self, transactions: List[Dict[str, Any]]) -> bytes:
        tx_hashes = [_hash_dict(tx) for tx in transactions]
        root, _ = merkle_tree(tx_hashes)
        return root

    # -------------- Proof-of-work --------------
    def _mine_block(
        self, index: int, prev_hash: bytes, merkle_root: bytes, txs: List[Dict[str, Any]]
    ) -> Block:
        target_prefix = b"\x00" * (self.difficulty // 2)
        nonce = 0
        while True:
            header = (
                index.to_bytes(4, "big")
                + int(time.time()).to_bytes(8, "big")
                + prev_hash
                + merkle_root
                + nonce.to_bytes(8, "big")
            )
            h = _sha256(header)
            if h.startswith(target_prefix):
                ts = int(time.time())
                return Block(
                    index=index,
                    timestamp=ts,
                    prev_hash=prev_hash,
                    merkle_root=merkle_root,
                    nonce=nonce,
                    hash=h,
                    transactions=txs,
                )
            nonce += 1

    def create_block(self, transactions: List[Dict[str, Any]]) -> Block:
        prev_block = self.chain[-1]
        merkle_root = self.build_merkle_root(transactions)
        block = self._mine_block(prev_block.index + 1, prev_block.hash, merkle_root, transactions)
        self.chain.append(block)
        return block

    def add_transaction(self, tx: Dict[str, Any]) -> None:
        self.pending_transactions.append(tx)

    def mine_pending(self) -> Optional[Block]:
        if not self.pending_transactions:
            return None
        block = self.create_block(self.pending_transactions)
        self.pending_transactions = []
        return block

    def is_chain_valid(self) -> bool:
        for i in range(1, len(self.chain)):
            prev = self.chain[i - 1]
            block = self.chain[i]
            if block.prev_hash != prev.hash:
                return False
            expected_root = self.build_merkle_root(block.transactions)
            if expected_root != block.merkle_root:
                return False
        return True


