import os
from dataclasses import dataclass
from typing import Dict

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, ed25519
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF


def _hkdf_sha256(shared_key: bytes, info: bytes) -> bytes:
    hkdf = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=os.urandom(16),
        info=info,
    )
    return hkdf.derive(shared_key)


@dataclass
class MessagingIdentity:
    ecdh_private_key: ec.EllipticCurvePrivateKey
    signing_private_key: ed25519.Ed25519PrivateKey

    @classmethod
    def generate(cls) -> "MessagingIdentity":
        return cls(
            ecdh_private_key=ec.generate_private_key(ec.SECP256R1()),
            signing_private_key=ed25519.Ed25519PrivateKey.generate(),
        )

    def public_keys(self) -> Dict[str, bytes]:
        return {
            "ecdh": self.ecdh_private_key.public_key().public_bytes(
                serialization.Encoding.DER,
                serialization.PublicFormat.SubjectPublicKeyInfo,
            ),
            "sign": self.signing_private_key.public_key().public_bytes(
                serialization.Encoding.Raw, serialization.PublicFormat.Raw
            ),
        }


class MessagingModule:
    """
    Secure messaging:
    - ECDH P-256 ephemeral key exchange
    - HKDF-derived AES-256-GCM key
    - Ed25519 signatures
    """

    def __init__(self, identity: MessagingIdentity):
        self.identity = identity

    def _load_peer_ecdh(self, peer_bytes: bytes) -> ec.EllipticCurvePublicKey:
        return serialization.load_der_public_key(peer_bytes)  # type: ignore[return-value]

    def _enc_key_for_peer(self, peer_pub_der: bytes) -> bytes:
        peer_pub = self._load_peer_ecdh(peer_pub_der)
        shared_key = self.identity.ecdh_private_key.exchange(ec.ECDH(), peer_pub)
        return _hkdf_sha256(shared_key, b"message_key")

    def send_message(self, recipient_pubkey: bytes, message: str) -> Dict[str, bytes]:
        enc_key = self._enc_key_for_peer(recipient_pubkey)
        nonce = os.urandom(12)
        encryptor = Cipher(
            algorithms.AES(enc_key), modes.GCM(nonce)
        ).encryptor()
        ciphertext = encryptor.update(message.encode("utf-8")) + encryptor.finalize()
        tag = encryptor.tag

        # Sign message hash (SHA-256)
        digest = hashes.Hash(hashes.SHA256())
        digest.update(ciphertext)
        msg_hash = digest.finalize()
        signature = self.identity.signing_private_key.sign(msg_hash)

        return {
            "sender_ecdh_pub": self.identity.ecdh_private_key.public_key().public_bytes(
                serialization.Encoding.DER,
                serialization.PublicFormat.SubjectPublicKeyInfo,
            ),
            "nonce": nonce,
            "ciphertext": ciphertext,
            "tag": tag,
            "signature": signature,
        }

    def receive_message(
        self, sender_sign_pub: bytes, payload: Dict[str, bytes]
    ) -> str:
        sender_ecdh_pub = payload["sender_ecdh_pub"]
        enc_key = self._enc_key_for_peer(sender_ecdh_pub)
        nonce = payload["nonce"]
        ciphertext = payload["ciphertext"]
        tag = payload["tag"]
        signature = payload["signature"]

        # Verify signature
        verify_key = ed25519.Ed25519PublicKey.from_public_bytes(sender_sign_pub)
        digest = hashes.Hash(hashes.SHA256())
        digest.update(ciphertext)
        msg_hash = digest.finalize()
        verify_key.verify(signature, msg_hash)

        decryptor = Cipher(
            algorithms.AES(enc_key), modes.GCM(nonce, tag)
        ).decryptor()
        plaintext = decryptor.update(ciphertext) + decryptor.finalize()
        return plaintext.decode("utf-8")


