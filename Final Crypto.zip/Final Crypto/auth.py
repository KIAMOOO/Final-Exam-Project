import base64
import hmac
import os
import time
from dataclasses import dataclass
from typing import Dict, Optional

import pyotp
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError


def secure_compare(a: bytes, b: bytes) -> bool:
    """Constant-time comparison for sensitive values."""
    return hmac.compare_digest(a, b)


def generate_cs_random_bytes(n: int) -> bytes:
    return os.urandom(n)


def password_strong_enough(pw: str) -> bool:
    if len(pw) < 10:
        return False
    has_upper = any(c.isupper() for c in pw)
    has_lower = any(c.islower() for c in pw)
    has_digit = any(c.isdigit() for c in pw)
    has_sym = any(not c.isalnum() for c in pw)
    return has_upper and has_lower and has_digit and has_sym


@dataclass
class UserRecord:
    username: str
    password_hash: str
    totp_secret: str
    backup_codes_hashes: Dict[str, str]  # code_id -> argon2 hash


class AuthModule:
    """
    In-memory authentication module:
    - Registration with Argon2id hashing
    - Login with rate limiting
    - TOTP MFA + backup codes
    - Session token via HMAC-SHA256
    """

    def __init__(self):
        self._users: Dict[str, UserRecord] = {}
        self._ph = PasswordHasher()
        self._session_key = generate_cs_random_bytes(32)
        self._login_attempts: Dict[str, Dict[str, float]] = {}
        self._lockout_threshold = 5
        self._lockout_window = 60.0  # seconds

    # ----------------- Registration -----------------
    def register(self, username: str, password: str) -> Dict[str, str]:
        if username in self._users:
            raise ValueError("User already exists")
        if not password_strong_enough(password):
            raise ValueError("Password too weak")

        pwd_hash = self._ph.hash(password)
        totp_secret = pyotp.random_base32()

        # generate backup codes (e.g., 5 one-time codes)
        backup_codes = {}
        for i in range(5):
            raw_code = base64.urlsafe_b64encode(generate_cs_random_bytes(6)).decode(
                "utf-8"
            ).rstrip("=")
            code_id = f"C{i+1}"
            backup_codes[code_id] = self._ph.hash(raw_code)

        self._users[username] = UserRecord(
            username=username,
            password_hash=pwd_hash,
            totp_secret=totp_secret,
            backup_codes_hashes=backup_codes,
        )

        otpauth_uri = pyotp.totp.TOTP(totp_secret).provisioning_uri(
            name=username, issuer_name="CryptoVault"
        )

        # Return TOTP URI and plaintext backup codes for the user to store
        return {
            "totp_uri": otpauth_uri,
            "totp_secret": totp_secret,
            "backup_codes": ",".join(
                f"{cid}:{code}"
                for cid, code in self._reconstruct_backup_codes(backup_codes).items()
            ),
        }

    def _reconstruct_backup_codes(self, hashed: Dict[str, str]) -> Dict[str, str]:
        """
        For demo purposes we can't invert hashes, but we also want to show codes at registration.
        In a real system, you'd generate and show plaintext codes before hashing & discarding them.
        Here we fake them as 'CODE_<id>' only when first generating them.
        """
        plain_codes: Dict[str, str] = {}
        for cid in hashed:
            plain_codes[cid] = f"CODE_{cid}"
        return plain_codes

    # ----------------- Rate limiting -----------------
    def _record_login_attempt(self, username: str, success: bool) -> None:
        rec = self._login_attempts.setdefault(
            username, {"fails": 0, "last_fail": 0.0, "locked_until": 0.0}
        )
        now = time.time()
        if success:
            rec["fails"] = 0
            rec["locked_until"] = 0.0
        else:
            if now - rec["last_fail"] > self._lockout_window:
                rec["fails"] = 0
            rec["fails"] += 1
            rec["last_fail"] = now
            if rec["fails"] >= self._lockout_threshold:
                rec["locked_until"] = now + self._lockout_window

    def _check_locked(self, username: str) -> bool:
        rec = self._login_attempts.get(username)
        if not rec:
            return False
        return time.time() < rec.get("locked_until", 0.0)

    # ----------------- Login + MFA -----------------
    def login(self, username: str, password: str, totp_or_backup: str) -> str:
        if self._check_locked(username):
            raise ValueError("Account temporarily locked due to failed attempts")

        user = self._users.get(username)
        if not user:
            self._record_login_attempt(username, False)
            raise ValueError("Invalid credentials")
        try:
            self._ph.verify(user.password_hash, password)
        except VerifyMismatchError:
            self._record_login_attempt(username, False)
            raise ValueError("Invalid credentials")

        # Check TOTP or backup code
        if not self._verify_totp_or_backup(user, totp_or_backup):
            self._record_login_attempt(username, False)
            raise ValueError("Invalid TOTP or backup code")

        self._record_login_attempt(username, True)
        return self._generate_session_token(username)

    def _verify_totp_or_backup(self, user: UserRecord, code: str) -> bool:
        # First try TOTP with small window
        totp = pyotp.TOTP(user.totp_secret)
        if totp.verify(code, valid_window=1):
            return True

        # Then backup codes: expect "C1:CODE" format
        if ":" in code:
            cid, raw = code.split(":", 1)
            stored_hash = user.backup_codes_hashes.get(cid)
            if not stored_hash:
                return False
            try:
                self._ph.verify(stored_hash, raw)
            except VerifyMismatchError:
                return False
            # consume backup code
            del user.backup_codes_hashes[cid]
            return True
        return False

    # ----------------- Session tokens -----------------
    def _generate_session_token(self, username: str, ttl: int = 3600) -> str:
        now = int(time.time())
        payload = f"{username}:{now}:{now+ttl}".encode("utf-8")
        sig = hmac.new(self._session_key, payload, "sha256").digest()
        token = base64.urlsafe_b64encode(payload + sig).decode("utf-8")
        return token

    def verify_session_token(self, token: str) -> Optional[str]:
        try:
            raw = base64.urlsafe_b64decode(token.encode("utf-8"))
        except Exception:
            return None
        if len(raw) < 32:
            return None
        payload, sig = raw[:-32], raw[-32:]
        expected = hmac.new(self._session_key, payload, "sha256").digest()
        if not secure_compare(sig, expected):
            return None
        parts = payload.decode("utf-8").split(":")
        if len(parts) != 3:
            return None
        username, issued, expires = parts
        if int(expires) < int(time.time()):
            return None
        return username


