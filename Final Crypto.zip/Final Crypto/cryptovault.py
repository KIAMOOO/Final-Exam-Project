import hashlib
import time
from typing import Any, Dict

from auth import AuthModule
from blockchain import BlockchainModule
from filesys import FileEncryptionModule
from messaging import MessagingIdentity, MessagingModule


class CryptoVault:
    """
    High-level orchestrator that ties all modules together and logs to the blockchain.
    """

    def __init__(self):
        self.auth = AuthModule()
        self.messaging_identity = MessagingIdentity.generate()
        self.messaging = MessagingModule(self.messaging_identity)
        self.files = FileEncryptionModule()
        self.ledger = BlockchainModule(difficulty=4)

    # -------------- Logging helpers --------------
    def _hash_str(self, s: str) -> str:
        return hashlib.sha256(s.encode("utf-8")).hexdigest()

    def _log_event(self, event: Dict[str, Any]) -> None:
        self.ledger.add_transaction(event)
        # For simplicity, mine immediately; in a real system you'd batch.
        self.ledger.mine_pending()

    # -------------- Auth integration --------------
    def register(self, username: str, password: str) -> Dict[str, str]:
        result = self.auth.register(username, password)
        event = {
            "type": "AUTH_REGISTER",
            "user_hash": self._hash_str(username),
            "timestamp": int(time.time()),
        }
        self._log_event(event)
        return result

    def login(self, username: str, password: str, totp_or_backup: str) -> str:
        success = False
        token = ""
        try:
            token = self.auth.login(username, password, totp_or_backup)
            success = True
            return token
        finally:
            event = {
                "type": "AUTH_LOGIN",
                "user_hash": self._hash_str(username),
                "timestamp": int(time.time()),
                "success": success,
            }
            self._log_event(event)

    # -------------- File operations --------------
    def encrypt_file(self, username: str, filepath: str, password: str) -> Dict[str, bytes]:
        result = self.files.encrypt_file(filepath, password)
        event = {
            "type": "FILE_ENCRYPT",
            "file_hash": self._hash_str(filepath),
            "user_hash": self._hash_str(username),
            "timestamp": int(time.time()),
            "encrypted_path_hash": self._hash_str(
                result["encrypted_path"].decode("utf-8")
            ),
        }
        self._log_event(event)
        return result

    def decrypt_file(
        self, username: str, enc_path: str, password: str, out_path: str
    ) -> Dict[str, bytes]:
        result = self.files.decrypt_file(enc_path, password, out_path)
        event = {
            "type": "FILE_DECRYPT",
            "file_hash": self._hash_str(out_path),
            "user_hash": self._hash_str(username),
            "timestamp": int(time.time()),
        }
        self._log_event(event)
        return result


