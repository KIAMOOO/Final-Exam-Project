## CryptoVault Final Exam Project

This project implements a small **crypto vault** that satisfies the requirements from your exam:

- **Module 1 – Authentication**
  - User registration with Argon2id password hashing and CSPRNG salt
  - Password strength validation
  - Login with constant‑time verification and basic rate limiting
  - Session token generation with HMAC‑SHA256
  - TOTP multi‑factor authentication (QR code + verification)
  - Backup codes with secure storage
- **Module 2 – Secure Messaging**
  - ECDH key exchange on P‑256 (ephemeral keys per session)
  - Shared secret derivation with HKDF
  - AES‑256‑GCM message encryption (`nonce || ciphertext || tag`)
  - Ed25519 digital signatures for messages
- **Module 3 – File Encryption System**
  - AES‑256‑GCM streaming encryption for files
  - Random file encryption key (FEK) encrypted with a master key derived from password (PBKDF2)
  - SHA‑256 integrity hash and HMAC‑SHA256 authenticity tag
- **Module 4 – Blockchain Audit Ledger**
  - Block structure with previous hash, Merkle root, timestamp, nonce
  - Merkle tree for transactions + inclusion verification
  - Simple Proof‑of‑Work with adjustable difficulty
  - Audit trail for auth and file events
- **Core Crypto (from scratch, educational)**
  - Simplified SHA‑256‑like hash function
  - Merkle tree with proof generation
  - XOR stream cipher with LFSR
  - RSA key generation + square‑and‑multiply modular exponentiation

The production‑style modules use Python’s `cryptography` and other vetted libraries, while the `core_crypto.py` module implements simplified algorithms "from scratch" for learning and to satisfy the core‑crypto requirements.

---

## Project Structure

```text
Final Crypto/
  README.md
  requirements.txt
  auth.py
  messaging.py
  filesys.py
  blockchain.py
  core_crypto.py
  cryptovault.py
  demo_cli.py
```

---

## Setup

1. **Create virtual environment (recommended)**

```bash
python -m venv venv
venv\Scripts\activate  # on Windows PowerShell
```

2. **Install dependencies**

```bash
pip install -r requirements.txt
```

---

## Running the Demo CLI

The `demo_cli.py` script shows a simple flow:

- Register a user
- Enable TOTP (prints a URI you can paste into an authenticator app, or shows QR as ASCII info)
- Login with password + TOTP
- Encrypt and decrypt a sample file
- Send and verify a secure message
- Print current blockchain height

Run:

```bash
python demo_cli.py
```

Follow on‑screen prompts for username, password, and TOTP code.

---

## Security Notes

- This project is **for educational / exam purposes** only.
- Do **not** use it in production.
- Secrets are kept in memory only (no real database) to keep the code short and focused.


